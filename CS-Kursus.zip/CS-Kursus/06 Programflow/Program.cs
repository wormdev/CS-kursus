﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _06_Programflow
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int xx = 1; xx < 11; xx++)
            {
                for (int yy = 1; yy < 11; yy++)
                {
                    string tal = (xx * yy).ToString();
                    if ((xx * yy) > 50)
                        Console.ForegroundColor = ConsoleColor.Yellow;
                    else
                        Console.ForegroundColor = ConsoleColor.White;
                    Console.Write(tal.PadLeft(4));
                }
                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.Gray;
            }



            // Hold console åben ved debug 
            if (System.Diagnostics.Debugger.IsAttached)
            {
                Console.Write("Press any key to continue . . . ");
                Console.ReadKey();
            }
            /*
         ---------- Output: ----------
        byte min: 0
        byte max: 255
        int min: -2147483648
        int max: 2147483647
        long min: -9223372036854775808
        long max: 9223372036854775807
        i = 10
        i = 10
        */



            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
            Console.WriteLine("1");
            for (int i = 0; i < 20; i++)
            {
                if (i % 3 != 0)
                    continue;
                if (i > 15)
                    break;
                Console.WriteLine(i);
            }
            // Hold console åben ved debug 
            if (System.Diagnostics.Debugger.IsAttached)
            {
                Console.Write("Press any key to continue . . . ");
                Console.ReadKey();
            }

        }
    }
}
