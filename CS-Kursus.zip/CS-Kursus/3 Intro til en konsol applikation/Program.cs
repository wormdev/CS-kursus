﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace _3_Intro_til_en_konsol_applikation
{
    class Program
    {
        static void Main(string[] args)
        {
            // Hold console åben ved debug
            if (System.Diagnostics.Debugger.IsAttached)
            {
                Console.Write("Press any key to continue . . . ");
                Console.ReadKey();
            }
            // Brug klassen System.Console til at udskrive 
            // tekst (strenge) til konsolen
            System.Console.WriteLine("Skriver...");

            // Hvis man benytter using System; 
            Console.WriteLine("Skriver...");

            // Hvis man benytter using static System.Console;
            WriteLine("Skriver...");

            // Metoden er overloaded (kan kaldes med flere argumenter)
            // så den kan kaldes med mange forskellige typer
            Console.WriteLine("text");       // string
            Console.WriteLine('c');          // char
            Console.WriteLine(1);            // Heltal
            Console.WriteLine(1.2);          // Kommatal (double)
            Console.WriteLine(DateTime.Now); // Dato

            // Overload til formatering
            Console.WriteLine("{0} {1} {2} {3:N2}", 1, "**", true, 33432.34);

            // Brug Write-metoden hvis man ikke 
            // ønsker linjeskift
            Console.Write("1 ");
            Console.Write("2 ");
            Console.Write("3 ");
            Console.WriteLine();

            // Skift eventuelt farve
            Console.ForegroundColor = ConsoleColor.Green;   // skriver med grøn
            Console.WriteLine("Skriver...");
            Console.ForegroundColor = ConsoleColor.Gray;    // default (grå)
            Console.WriteLine("Skriver...");

            // Slet indhold på konsol
            // Console.Clear();

            /*
             ---------- Output: ----------

            Skriver...
            Skriver...
            Skriver...
            text
            c
            1
            1,2
            29-10-2018 18:29:00
            1 ** True 33.432,34
            1 2 3 
            Skriver...
            Skriver...

            */
            // Læs fra linje
            string input = Console.ReadLine();
            
            ConsoleKeyInfo k = Console.ReadKey();
            if (k.Key == ConsoleKey.A) { }
            if (k.Key == ConsoleKey.Escape) { }

        }
    }
}
