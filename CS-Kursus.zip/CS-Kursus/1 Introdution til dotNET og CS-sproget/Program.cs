﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1_Introdution_til_dotNET_og_CS_sproget
{
    class Program
    {
        static void Main(string[] args)
        {
            // Her er en kommentar
            int antal = 3;
            bool skriv = true;
            string navn = "mikkel";
            if (antal < 5)
            {
                for (int i = 0; i < antal; i++)
                {
                    if (skriv)
                    {
                        Console.WriteLine(navn);
                    }
                }
            }
            else
            {
                Console.WriteLine("Antal er for stort");
            }
        }
    }
}
