﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04_Simple_variabler__1_
{
    class Program
    {
        static void Main(string[] args)
        {
            //Erklær variabel
            int heltal = 10;

            //Opskriv med 1
            heltal++;

            //Print
            Console.Write(heltal);
            Console.Write(" ");
            Console.ReadKey();

            //Nedskriv med 1
            heltal--;

            Console.Write(heltal);
            Console.Write(" ");

            //
            Console.ReadKey();
        }
    }
}
